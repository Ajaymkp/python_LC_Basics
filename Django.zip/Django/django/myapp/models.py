from django.db import models

class Student(models.Model):
    id=models.IntegerField(primary_key=True)
    name=models.CharField(max_length=20)
    batch=models.IntegerField()

    def __str__(self):
        return self.name